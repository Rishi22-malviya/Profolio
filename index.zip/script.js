$(document).ready(function(){
  $(window).scroll(function(){
  	if(this.scrollY > 20){
        $('.nav-bar').addClass("sticky");
  	}else{
        $('.nav-bar').removeClass("sticky");
  	}
  })

 // toggle menu/navbar script //

  $('.menu-bar').click(function(){
     $('.nav-bar .menu').toggleClass("active");
     $('.nav-bar i').toggleClass("active");
  });

});







